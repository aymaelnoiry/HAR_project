from kivy.core.window import Window
from kivy.properties import StringProperty
from kivy.utils import get_color_from_hex

from kivymd.app import MDApp
from kivymd.uix.behaviors import RoundedRectangularElevationBehavior
from kivymd.uix.card import MDCard


class MainApp(MDApp):
    pass


Window.size = (280, 500)
MainApp().run()