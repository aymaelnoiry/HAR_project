# Movement_Analysis_Application

## Getting started

1. Install git on your PC. To do so, check this [page](https://git-scm.com/).
2. Execute the command *git clone* on a bash window:
```bash
git clone https://mygit.th-deg.de/casestudies/movement_analysis_application.git
```
3. Create a development environment for python and install the packages mentioned in the *requirements.txt*.
